﻿/*
 * PLUGIN DATA
 *
 * Swedish language file.
 *
 * Author: Magnus Holm (holmen@brasse.se)
 */

 theUILang.getData		= "Hämta fil";
 theUILang.cantAccessData	= "Webbserveranvändaren har inte åtkomst till data för denna torrent.";

thePlugins.get("data").langLoaded();
