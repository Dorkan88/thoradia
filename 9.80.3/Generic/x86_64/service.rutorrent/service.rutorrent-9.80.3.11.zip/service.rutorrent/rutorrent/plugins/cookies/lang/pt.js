﻿/*
 * PLUGIN COOKIES
 *
 * Portuguese language file.
 *
 * Author: 
 */

 theUILang.cookiesDesc		= "Cookies (Format: host|cookie1;cookie2...)";
 theUILang.cookiesName		= "Cookies";

thePlugins.get("cookies").langLoaded();