﻿/*
 * PLUGIN CHUNKS
 *
 * Polish language file.
 *
 * Author: 
 */

 theUILang.Chunks		= "Części";
 theUILang.cAvail		= "Dostępne";
 theUILang.cDownloaded		= "Pobrane";
 theUILang.cMode		= "Tryb";
 theUILang.chunksCount		= "Ilość";
 theUILang.chunkSize		= "Rozmiar";
 theUILang.cLegend		= "Legenda";
 theUILang.cLegendVal		= [ "4 części na komórkę", "1 część na komórkę" ];

thePlugins.get("chunks").langLoaded();
