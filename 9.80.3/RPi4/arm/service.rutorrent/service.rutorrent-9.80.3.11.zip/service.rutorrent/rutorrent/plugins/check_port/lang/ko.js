﻿/*
 * PLUGIN CHECK_PORT
 *
 * Korean language file.
 *
 * Author: Limerainne (limerainne@gmail.com)
 */

 theUILang.checkPort		= "포트 상태 검사";
 theUILang.portStatus		= [
 				  "포트 상태 알 수 없음",
 				  "포트 닫힘",
 				  "포트 열림"
 				  ];

thePlugins.get("check_port").langLoaded();
