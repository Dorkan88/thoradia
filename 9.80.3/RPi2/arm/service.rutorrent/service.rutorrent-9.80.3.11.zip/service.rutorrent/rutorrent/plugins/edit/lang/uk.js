﻿/*
 * PLUGIN EDIT
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (oleksandr@natalenko.name)
 */

 theUILang.EditTrackers			= "Редагувати...";
 theUILang.EditTorrentProperties	= "Властивості торента";
 theUILang.errorAddTorrent		= "Сталася помилка додавання торента";
 theUILang.errorWriteTorrent		= "Сталася помилка записування у файл";
 theUILang.errorReadTorrent		= "Сталася помилка читання з файлу";
 theUILang.cantFindTorrent		= "Вихідний файл торента для цього завантаження не знайдено."

thePlugins.get("edit").langLoaded();