﻿/* PLUGIN _CLOUDFLARE
 *
 * Swedish language file.
 *
 * Author: 
 */

 theUILang.cannotLoadCloudscraper		= "_cloudflare plugin: cloudscraper module can't be loaded in Python";

thePlugins.get("_cloudflare").langLoaded();
