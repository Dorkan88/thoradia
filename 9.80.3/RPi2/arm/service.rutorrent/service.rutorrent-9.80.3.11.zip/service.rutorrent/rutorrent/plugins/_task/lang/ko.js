﻿/*
 * PLUGIN _TASK
 *
 * Korean language file.
 *
 * Author: Limerainne (limerainne@gmail.com)
 */

 theUILang.tskCommand		= "실행 중...";
 theUILang.tskCommandDone	= "완료.";
 theUILang.tskConsole		= "콘솔";
 theUILang.tskErrors		= "진단";
 theUILang.tskBackground	= "숨기기";
 theUILang.tskStart		= "시작됨";
 theUILang.tskFinish		= "완료됨";
 theUILang.tskElapsed		= "경과";
 theUILang.tskPlugin		= "플러그인";
 theUILang.tskDeletePrompt	= "정말 선택한 작업을 삭제할까요?";
 theUILang.tskDelete		= "작업 삭제";
 theUILang.tskActivate		= "활성화";
 theUILang.tskRemove		= "제거";
 theUILang.tskRefresh		= "새로고침";
 theUILang.tskRunning		= "실행 중";
 theUILang.tskArg		= "매개 변수";
 theUILang.tskTasks		= "작업";

thePlugins.get("_task").langLoaded();
