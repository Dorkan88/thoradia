﻿/*
 * PLUGIN CHUNKS
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.Chunks		= "Части";
 theUILang.cAvail		= "Доступность";
 theUILang.cDownloaded		= "Наличие";
 theUILang.cMode		= "Показывать";
 theUILang.chunksCount		= "Кол-во частей";
 theUILang.chunkSize		= "Размер части";
 theUILang.cLegend		= "Легенда";
 theUILang.cLegendVal		= [ "4 части на клетку", "1 часть на клетку" ];

thePlugins.get("chunks").langLoaded();